# 2) Escreva um programa para calcular quantos dias levará para a colônia de uma bactéria A
# ultrapassar ou igualar a colônia de uma bactéria B, com base nas taxas de crescimento de
# 3% e 1,5% respectivamente. Considere que a colônia A inicia com 4 elementos e a B com 10.


colA = 4
colB = 10
dias = 0

while colA <= colB:
    colA += colA * 0.03
    colB += colB * 0.015
    dias += 1

print(f'Demoraram {dias} dias para a colônia A e a colônia B igualarem em número de elementos.\nColônia A: {colA:.0f} elementos.\nColônia B: {colB:.0f} elementos.')