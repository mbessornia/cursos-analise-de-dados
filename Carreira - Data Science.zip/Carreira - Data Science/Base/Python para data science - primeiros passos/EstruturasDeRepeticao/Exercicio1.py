i = 1

while i <= 2:
    numero = int(input('Digite um número: '))
    print(numero)
    i += 1