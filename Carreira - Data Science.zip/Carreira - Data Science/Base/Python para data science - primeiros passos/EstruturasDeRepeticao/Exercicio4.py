# Desenvolva um programa que leia um conjunto indeterminado de temperaturas em Celsius
# e informe a média delas. A leitura deve ser encerrada ao ser enviado o valor -273°C.

i = 0
temperatura = 0
temperatura_total = 0

while i < 5:
    temperatura = int(input('Digite uma temperatura em Celsius: '))
    temperatura_total += temperatura

    if temperatura == -273:
        print('Você digitou a temperatura proibida, encerrando programa...')
        break
    else:
        i += 1

if i == 5:
    print(f'A média das temperaturas é: {temperatura_total / i}°C')
