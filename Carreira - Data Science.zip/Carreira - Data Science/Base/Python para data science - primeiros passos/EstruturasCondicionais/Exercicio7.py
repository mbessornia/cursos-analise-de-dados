turno = str.lower(input('Em que turno você estuda?\n\nEscolha entre: Noturno, Vespertino ou Matutino: '))

if turno == 'noturno':
    print('Boa noite')
elif turno == 'vespertino':
    print('Boa tarde')
elif turno == 'matutino':
    print('Bom dia')
else:
    print('Turno inválido!')
