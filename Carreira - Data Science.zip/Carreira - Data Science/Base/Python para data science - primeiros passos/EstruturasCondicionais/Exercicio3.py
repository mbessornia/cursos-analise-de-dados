vogal = ['a', 'e', 'i', 'o', 'u']

letra = str.lower(input('Digite uma letra'))

if letra in vogal:
    print(
        f'{letra} é uma vogal!')
else:
    print(f'{letra} é uma consoante.')
