n1 = int(input('Digite o primeiro numero: '))
n2 = int(input('Digite o segundo numero: '))

if n1 > n2:
    print(f'{n1} é o maior número.')
else:
    print(f'{n2} é o maior número')
