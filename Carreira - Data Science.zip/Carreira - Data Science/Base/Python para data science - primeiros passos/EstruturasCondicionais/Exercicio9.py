numero = float(input('Digite um número: '))

if numero % 1 == 0:
    print(f'{numero} é um número inteiro')
else:
    print(f'{numero} é um número decimal')
