ano1 = float(input('Digite o preço médio do carro no ano 2020:'))
ano2 = float(input('Digite o preço médio do carro no ano 2021:'))
ano3 = float(input('Digite o preço médio do carro no ano 2022:'))

if ano1 > ano2 and ano1 > ano3:
    print('A maior média foi em 2020')
elif ano2 > ano1 and ano2 > ano3:
    print('A maior média foi em 2021')
elif ano3 > ano1 and ano3 > ano2:
    print('A maior média foi em 2022')
