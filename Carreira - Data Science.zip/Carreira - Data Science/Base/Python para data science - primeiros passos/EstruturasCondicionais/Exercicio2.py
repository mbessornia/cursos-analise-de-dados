percentual_crescimento = float(input('Digite o percentual de crescimento da empresa: '))

if percentual_crescimento >= 0:
    print('O percentual foi positivo')
else:
    print('O percentual foi negativo')
